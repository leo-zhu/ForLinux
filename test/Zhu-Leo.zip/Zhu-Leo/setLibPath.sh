
## specify shared library path
LD_LIBRARY_PATH=lib/shared 

