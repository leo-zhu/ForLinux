//var x = db.getSiblingDB('MCK_03');
var x = db.getSiblingDB('zleo_QA_MRR');


db = x;
var delim = '|'

var memberAlerts = db.ui_MemberAlerts.find({
    ruleId: 'CDC2'
});
print("memberAlerts:", memberAlerts.count());

var cols = [
    'memId'
    ,'result'
    ,'dos'
    ,'provName'
    ,'dob'
    ,'fName'
    ,'lName'
//    ,'planId'     // planId not available
//    ,'planName'   // planName not available
    ,'phone'
    ,'addr1'
    ,'addr2'
    ,'state'
    ,'zip'
    ,'entity'
];

print(cols.join(delim));

memberAlerts.forEach(function(member) {

    var memId = member.memId;
//    print("memId:", memId);

    var members = db.getCollection('pop_cMembers')
        members.find({
            memId: member.memId
        }).forEach(function(members) {
            member.addr1 = members.addr1;
            member.addr2 = members.addr2;
            member.fName = members.fName;
            member.lName = members.lName;
        });

    var cursor = db.pop_cLabClaims.aggregate([{
        "$match": {
            $and: [{
                "dos": {
                    "$gte": new Date("2019-06-01T00:00:01Z"),
                    "$lt": new Date("2021-11-01T00:00:01Z")
                }
            }, {
                "memId": memId
            }, {
                loinc: "4548-4"
            }]
        }
    }, {
        $sort: {
            dos: -1
        }
    }, {
        $group: {
            _id: {
                memId: "$memId"
            },
            dos: {
                $first: "$dos"
            },
            result: {
                $max: "$result"
            }
        }
        //}, {
        //    $out: "loinc_aggregation"
}])

cursor.forEach(function(claim) {
    var dosdt = new Date(claim.dos);
    dosdt.setDate(dosdt.getDate());
    var dosDateString = ('0' + (dosdt.getMonth() + 1)).slice(-2) + '/' +
        ('0' + dosdt.getDate()).slice(-2) + '/' +
        dosdt.getFullYear();
    var dos = dosDateString;
    var result = claim.result;
    var memId = claim._id.memId;
    var provName = member.provName;
    var dobdt = new Date(member.dob);
    dobdt.setDate(dobdt.getDate());
    var dobDateString = ('0' + (dobdt.getMonth() + 1)).slice(-2) + '/' +
        ('0' + dobdt.getDate()).slice(-2) + '/' +
        dobdt.getFullYear();
    var dob = dobDateString;
    var fName = member.fName;
    var lName = member.lName;
    //        var planId = member.activePlans[0].planId;
    //        var planName = member.activePlans[0].planName;
    var phone = member.phone;
    var state = member.state;
    var zip = member.zip;
    var addr1 = member.addr1;
    var addr2 = member.addr2;
    var entity = member.ipaId;
//    print(memId + "|" + result + "|" + dos + "|" + provName + "|" + dob + "|" + fName + "|" + lName + "|" + planId + "|" + planName + "|" + phone + "|" + addr1 + "|" + addr2 + "|" + state + "|" + zip + "|" + entity);
    print(memId + "|" + result + "|" + dos + "|" + provName + "|" + dob + "|" + fName + "|" + lName + "|" + phone + "|" + addr1 + "|" + addr2 + "|" + state + "|" + zip + "|" + entity);
});
})
