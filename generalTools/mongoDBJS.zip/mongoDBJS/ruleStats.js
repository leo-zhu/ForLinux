
// db.out_engine_QA_06_20220411_06_01.find({"hedis._dbgRuleId" : "CDC", "hedis.0.ruleClass": "P4P", "hedis.0.alerts._dbgRuleName":"CDC7", "hedis.0.alerts.productLines":"Commerical"}).count()


function stats(sourceDB, sourceCollection, ruleId, ruleClass, ruleName, productLine) {
    print("---------------------------------------------------");
    print("Stats : " + sourceDB + ", " + sourceCollection + ", " + ruleId + ", " + ruleClass + ", " + ruleName + ", " + productLine);
    db = db.getSiblingDB(sourceDB);
    let n0 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.0.ruleClass" : ruleClass, "hedis.0.alerts._dbgRuleName" : ruleName, "hedis.0.alerts.productLines" : productLine}).count();
    let n1 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.1.ruleClass" : ruleClass, "hedis.1.alerts._dbgRuleName" : ruleName, "hedis.1.alerts.productLines" : productLine}).count();
    let n2 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.2.ruleClass" : ruleClass, "hedis.2.alerts._dbgRuleName" : ruleName, "hedis.2.alerts.productLines" : productLine}).count();
    let n3 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.3.ruleClass" : ruleClass, "hedis.3.alerts._dbgRuleName" : ruleName, "hedis.3.alerts.productLines" : productLine}).count();
    let n4 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.4.ruleClass" : ruleClass, "hedis.4.alerts._dbgRuleName" : ruleName, "hedis.4.alerts.productLines" : productLine}).count();
    let n5 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.5.ruleClass" : ruleClass, "hedis.5.alerts._dbgRuleName" : ruleName, "hedis.5.alerts.productLines" : productLine}).count();
    let n6 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.6.ruleClass" : ruleClass, "hedis.6.alerts._dbgRuleName" : ruleName, "hedis.6.alerts.productLines" : productLine}).count();
    let n7 = db[sourceCollection].find({"hedis._dbgRuleId" : ruleId, "hedis.7.ruleClass" : ruleClass, "hedis.7.alerts._dbgRuleName" : ruleName, "hedis.7.alerts.productLines" : productLine}).count();
    let total = n1 + n2 + n3 + n4 + n5 + n6 + n7;
    print("n0=" + n0 + " n1=" + n1 + " n2=" + n2 + " n3=" + n3 + " n4=" + n4 + " n5=" + n5 + " n6=" + n6 + " n7=" + n7);
    print("Total=" + total + "|" + ruleName + "|" + productLine + "|" + ruleClass); 
}

sourceDB = "QA_06";
sourceCollection = "out_engine_QA_06_20220411_06_01";
ruleId = "CDC";

ruleClasses = ["HEDIS", "P4P"];
productLines = ["Commercial", "Medicare", "Medicaid"];
ruleNames = ["CDC1", "CDC2", "CDC4", "CDC7", "CDC9", "CDC10", "CDCCMB1"];

for (let m = 0; m < ruleClasses.length; m++) {
    let rc = ruleClasses[m];
    for (let i = 0; i < productLines.length; i++) {
        let pl = productLines[i];
        for (let j = 0; j < ruleNames.length; j++) {
            let rn = ruleNames[j];
            stats(sourceDB, sourceCollection, ruleId, rc, rn, pl);
        }
    }
}

