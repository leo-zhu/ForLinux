dbname=zTest2019_AMM_SMD_MPM
year=2018
runDate=$[$year+2]0401
eoyDate=${year}1231


##  batch process with jid
jid=2019043001
./jobManifest  --jobId=${jid} --batchSize=2000 --mongoUserName=build --mongoHostName=localhost --mongoDbName=${dbname} --mongoSrcHostName=devmdb-app1 --mongoSrcDbName=${dbname} --eoyDate=$eoyDate --dropJob
glog2 ./analyticsEngine  -r $runDate -y $year -d ../data/kb --cfgfile ../etc/InitConfig.json -j $jid --mongoHost localhost |& tee out.${dbname}.${jid}


##  single member mode without jid
##mid=MMA-HEDIS-95084
##glog8 ./analyticsEngine -r $runDate -y $year --nthreadsworker 1 -d ../data/kb --cfgfile ../etc/InitConfig.json -m $mid |& tee out.${dbname}.$mid
##gdb8 --args ./analyticsEngine  -r $runDate -y $year --nthreadsworker 1 -d ../data/kb --cfgfile ../etc/InitConfig.json -m $mid

