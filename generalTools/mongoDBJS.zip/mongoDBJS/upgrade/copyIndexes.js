//  copy indexes from sourceDB to targetDB
//  1) With query/filter
//  2) Indexes copied and background setting to true

function copyCollection(sourceDB, targetDB, collection, query) {
    print("---------------------------------------------------");
    print("copy collection : " + sourceDB + " " + targetDB + " " + collection);
    print("query : ");
    printjson(query);
    db = db.getSiblingDB(sourceDB);
    var indexKeys = db[collection].getIndexKeys();
    //print("source collection count : " + db[collection].count());
    print("source collection index keys : ");
    printjson(indexKeys);
    //var docs = db[collection].find(query);
    //var queryCount = docs.count();
    //print("source query count : " + queryCount);

    db = db.getSiblingDB(targetDB);
    for (var i = 1; i < indexKeys.length; i++) {
        db[collection].createIndex(indexKeys[i], {background : true});
    }
    print("target collection index : ");
    printjson(db[collection].getIndexes());
    //docs.forEach(function(p) { db[collection].insert(p); }); 
    print("target collection count : " + db[collection].count());
    db.getCollectionNames();
    print();
}

var sourceDB = "QA_SC";
var targetDB = "zleo_QA_SC";

var query = {};

print("srcDB: ", sourceDB);
print("tgtDB: ", targetDB);
print("collection: ", collectionName);
copyCollection(sourceDB, targetDB, collectionName, query);

