for ccc in "kb_cProviderSpecialty" "officeIpaXmap" "pop_cEnrolls" "pop_cLabClaims" "pop_cMasterPatientIndex" "pop_cMedClaims" "pop_cMembers" "pop_cOrgHierarchy" "pop_cPayerPlan" "pop_cProviderGrps" "pop_cProviders" "pop_cRxClaims" "pop_cUDF" "pop_cUserOrg" "providerOfficeXmap"; 
do
    echo "ccc: $ccc";
    mongo --quiet --eval "var collectionName='$ccc'" copyIndexes.js
    echo "ccc: $ccc";
done
