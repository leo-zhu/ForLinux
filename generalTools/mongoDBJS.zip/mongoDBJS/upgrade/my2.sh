for ccc in "pop_cMedClaims" "pop_cOrgHierarchy"
do
    echo "ccc: $ccc";
    mongo --quiet --eval "var collectionName='$ccc'" copyCollection.js &
    echo "ccc: $ccc";
done
