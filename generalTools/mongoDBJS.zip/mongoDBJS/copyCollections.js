//  copy collections from sourceDB to targetDB
//  1) With query/filter
//  2) Indexes copied and background setting to true

function copyCollection(sourceDB, targetDB, collection, query) {
    print("---------------------------------------------------");
    print("copy collection : " + sourceDB + " " + targetDB + " " + collection);
    print("query : ");
    printjson(query);
    db = db.getSiblingDB(sourceDB);
    var indexKeys = db[collection].getIndexKeys();
    print("source collection count : " + db[collection].count());
    print("source collection index keys : ");
    printjson(indexKeys);
    var docs = db[collection].find(query);
    var queryCount = docs.count();
    print("source query count : " + queryCount);

    db = db.getSiblingDB(targetDB);
    for (var i = 1; i < indexKeys.length; i++) {
        db[collection].createIndex(indexKeys[i], {background : true});
    }
    print("target collection index : ");
    printjson(db[collection].getIndexes());
    docs.forEach(function(p) { db[collection].insert(p); }); 
    print("target collection count : " + db[collection].count());
    db.getCollectionNames();
    print();
}

var sourceDB = "HedisCert2019";
var targetDB = "zTest2019_DMS";
//var targetDB = "zTest2019_AMB_AMR_AMM_CBP_SPC_WCC";
var collections = {};
var query = {};

collections = ["cfg_init", 
               "pop_cProviders"];
query = {};
for (var i = 0; i < collections.length; i++) { 
    var collectionName = collections[i]; 
    copyCollection(sourceDB, targetDB, collectionName, query);
}

collections = ["pop_cEnrolls", 
               "pop_cLabClaims", 
               "pop_cMMReport", 
               "pop_cMedClaims", 
               "pop_cMembers", 
               "pop_cObservations", 
               "pop_cRxClaims", 
               "pop_cRxClinical"];
query = {"memId" : /DMS-HEDIS/};
//query = {$or: [{"memId" : /AMB-HEDIS/}, {"memId": /AMR-HEDIS/}, {"memId": /AMM-HEDIS/}, {"memId": /CBP-HEDIS/}, {"memId": /SPC-HEDIS/}, {"memId": /WCC-HEDIS/}]};
for (var i = 0; i < collections.length; i++) { 
    var collectionName = collections[i]; 
    copyCollection(sourceDB, targetDB, collectionName, query);
}

