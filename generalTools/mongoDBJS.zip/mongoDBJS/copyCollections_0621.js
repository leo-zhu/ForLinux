//  copy collections from sourceDB to targetDB
//  1) With query/filter
//  2) Indexes copied and background setting to true

function copyCollection(sourceDB, targetDB, collection, query) {
    print("---------------------------------------------------");
    print("copy collection : " + sourceDB + " " + targetDB + " " + collection);
    print("query : ");
    printjson(query);
    db = db.getSiblingDB(sourceDB);
    var indexKeys = db[collection].getIndexKeys();
    print("source collection count : " + db[collection].count());
    print("source collection index keys : ");
    printjson(indexKeys);
    var docs = db[collection].find(query);
    var queryCount = docs.count();
    print("source query count : " + queryCount);

    db = db.getSiblingDB(targetDB);
    for (var i = 1; i < indexKeys.length; i++) {
        db[collection].createIndex(indexKeys[i], {background : true});
    }
    print("target collection index : ");
    printjson(db[collection].getIndexes());
    docs.forEach(function(p) { db[collection].insert(p); }); 
    print("target collection count : " + db[collection].count());
    db.getCollectionNames();
    print();
}

var sourceDB = "zleo_QA_06";
var targetDB = "zleo_SHP_Test_0624";
var collections = {};
var query = {};

collections = ["cfg_init", 
               "kb_cProviderSpecialty",
               "pop_cPayerPlan",
               "pop_cSpecialist",
               "pop_cProviders"];
query = {};
for (var i = 0; i < collections.length; i++) { 
    var collectionName = collections[i]; 
    copyCollection(sourceDB, targetDB, collectionName, query);
}

collections = ["pop_cEnrolls", 
               "pop_cLabClaims", 
               "pop_cMMReport", 
               "pop_cMedClaims", 
               "pop_cMembers", 
               "pop_cObservations", 
               "pop_cRxClaims", 
               "pop_cRxClinical"];
//query = {memId : /DMS-HEDIS/};

// Test cases for HCA-10252, from QA_06
//query = {$or: [{memId: "12668"},  {memId: "120537"}, {memId: "102912"}, {memId: "104530"}, 
//               {memId: "105634"}, {memId: "128563"}, {memId: "91668"},  {memId: "10109"}, 
//               {memId: "12822"},  {memId: "177104"}, {memId: "24250"}]};

// Test case for one dual enrolled member, and one Commercial member, same region (METRO), CDC alerts, for HCA-10252, from QA_06
query = {$or: [{memId: "14619"},  {memId: "21228"}]};

for (var i = 0; i < collections.length; i++) { 
    var collectionName = collections[i]; 
    copyCollection(sourceDB, targetDB, collectionName, query);
}

