$mongo
>use QA_STN2
>db.pop_cMedClaims.find({"dosThru" :{$exists:1}, "dischDt" : {$exists:1}}, {dosThru:1, dischDt:1}).pretty()
